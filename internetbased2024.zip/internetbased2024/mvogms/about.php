
<div class="content py-3">
    <div class="card rounded-0 card-outline card-navy shadow" >
        <div class="card-body rounded-0">
            <h2 class="text-center">About</h2>
            <center><hr class="bg-navy border-navy w-25 border-2"></center>
            <div>
                <?= file_get_contents("about.html") ?>
            </div>
        </div>
    </div>
</div>